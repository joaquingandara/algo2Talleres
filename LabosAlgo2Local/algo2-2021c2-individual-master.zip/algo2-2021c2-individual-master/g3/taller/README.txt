
Aquí se ubica el taller 3 (sección 3.2 de la guía).
En este directorio debe encontrarse el archivo CMakeLists.txt

