
Aquí se ubica el taller 2 (sección 3.2 de la guía).
En este directorio debe encontrarse el archivo CMakeLists.txt

